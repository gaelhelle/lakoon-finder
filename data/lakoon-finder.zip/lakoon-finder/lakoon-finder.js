const axios = require("axios");

const SOLANA_RPC_APIS = {
  mainnet: {
    name: "mainnet",
    url: "https://api.mainnet-beta.solana.com",
  },
  testnet: {
    name: "testnet",
    url: "https://api.testnet.solana.com",
  },
  devnet: {
    name: "devnet",
    url: "https://api.devnet.solana.com/",
  },
};

const lakoonFinder = async (mintAddress) => {
  try {
    const transactions = await getAllTransactions(mintAddress);
    const result = await getTransfers(transactions);

    delete result.blockTime;
    result.mintAddress = mintAddress;
    console.log(result);
  } catch (err) {
    console.log(err);
  }
};

const getAllTransactions = async (mintAddress) => {
  try {
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    const data = {
      jsonrpc: "2.0",
      id: 1,
      method: "getSignaturesForAddress",
      params: [mintAddress],
    };

    const result = await axios.post(SOLANA_RPC_APIS.mainnet.url, data, config);

    return result.data.result;
  } catch (error) {
    console.log(error);
  }
};

const getTransfers = async (transactions) => {
  let transfers = [];

  try {
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    await Promise.all(
      transactions.map(async (transaction) => {
        const data = {
          jsonrpc: "2.0",
          id: 1,
          method: "getTransaction",
          params: [transaction.signature, { encoding: "jsonParsed" }],
        };

        await axios
          .post(SOLANA_RPC_APIS.mainnet.url, data, config)
          .then((result) => {
            const blockTime = result?.data?.result?.blockTime;
            const slot = result?.data?.result?.slot;

            const transfer =
              result?.data?.result?.transaction?.message?.instructions.filter(
                (instruction) => instruction?.parsed?.type === "create"
              );

            if (transfer.length) {
              const data = {
                blockTime,
                slot,
                wallet: transfer[0]?.parsed?.info?.wallet,
              };

              transfers.push(data);
            }
          });
      })
    );

    transfers.sort((a, b) => a.blockTime - b.blockTime);

    return transfers[0];
  } catch (error) {
    console.log(error);
  }
};

lakoonFinder("AJ3LyKbRCS3CJwYNf5vCQ1nXM8ZjZCBqhWA9TzekQ2xn");
