To run : 
- npm i
- node lakoon-finder.js

And you can change the input at the end of the file => lakoonFinder("AJ3LyKbRCS3CJwYNf5vCQ1nXM8ZjZCBqhWA9TzekQ2xn");

Go check out the online version : https://lakoon-finder.vercel.app/ 

